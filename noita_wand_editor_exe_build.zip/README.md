# Building NoitaWandEditor.exe (no Windows machine needed)

This folder is a ready-to-upload bundle that gets GitHub to build the
`.exe` for you, on their own Windows servers, for free. You don't need
Windows, Python, or PyInstaller installed anywhere yourself.

## One-time setup (about 2 minutes)

1. Go to https://github.com/new and create a new repository.
   - Any name (e.g. `noita-wand-editor`)
   - Public or Private both work
   - Don't add a README/gitignore/license — leave it empty

2. On the new repo's page, click **"uploading an existing file"**
   (or drag-and-drop) and upload **all three items from this folder**,
   keeping the folder structure:
   - `noita_wand_editor_gui.py`
   - `.github/workflows/build-exe.yml`
   - `README.md` (optional)

   If GitHub's web uploader flattens the `.github` folder, instead use
   "Add file" → "Create new file", name it exactly
   `.github/workflows/build-exe.yml` (typing the slashes creates the
   folders automatically), and paste the workflow file's contents in.

3. Commit the files (the green "Commit changes" button).

## Getting the exe

1. Committing the files automatically starts the build. Click the
   **"Actions"** tab at the top of your repo.
2. You'll see a run called "Build Windows exe" — click it, wait for
   the green checkmark (~1-2 minutes).
3. Scroll down to **Artifacts** and click
   **NoitaWandEditor-windows-exe** to download a zip containing
   `NoitaWandEditor.exe`.
4. Unzip it anywhere on your Windows machine and double-click to run —
   no Python install needed on that machine either.

## Updating later

Any time I (or you) change `noita_wand_editor_gui.py`, just re-upload
the new version to the same repo (or use `git push` if you clone it
locally) — the workflow reruns automatically and a fresh exe shows up
under Actions → Artifacts.

## Why this exists

Building a Windows `.exe` requires either a Windows machine or a
cross-compilation toolchain — neither of which is available in the
sandbox I run code in. GitHub Actions' `windows-latest` runner is a
real, temporary Windows VM, so this produces an actual native exe,
not a workaround or approximation.
